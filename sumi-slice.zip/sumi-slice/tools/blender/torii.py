# Headless Blender example: builds a torii and exports GLB.
#   /Applications/Blender.app/Contents/MacOS/Blender -b -P tools/blender/torii.py
# Pattern for agents: one script per prop, parameters at the top, export to public/models/.
# (Authored as a template; not executed in the guide's build environment. Run it once and check.)
import bpy, math, os
H, W = 6.4, 5.4
OUT = os.path.join(os.getcwd(), "public", "models", "torii.glb")
bpy.ops.wm.read_factory_settings(use_empty=True)
red = bpy.data.materials.new("vermilion"); red.diffuse_color = (0.72, 0.22, 0.16, 1)
blk = bpy.data.materials.new("black"); blk.diffuse_color = (0.05, 0.05, 0.05, 1)
def add(obj, mat): obj.data.materials.append(mat); return obj
for sx in (-1, 1):
    bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=H*0.055, depth=H, location=(sx*W/2, 0, H/2))
    add(bpy.context.object, red).rotation_euler[1] = sx * 0.025
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, H*0.74)); o = bpy.context.object
o.scale = (W*1.18, H*0.07*2, H*0.055*1.3); add(o, red)
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, H*0.97)); o = bpy.context.object
o.scale = (W*1.5, H*0.055*2.4, H*0.08); add(o, blk)
bpy.ops.object.select_all(action="SELECT")
os.makedirs(os.path.dirname(OUT), exist_ok=True)
bpy.ops.export_scene.gltf(filepath=OUT, export_format="GLB", use_selection=True, export_yup=True)
print("wrote", OUT)

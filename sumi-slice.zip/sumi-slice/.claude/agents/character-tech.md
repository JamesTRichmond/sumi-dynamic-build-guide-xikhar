---
name: character-tech
description: Integrates the hero GLB — scale, facing, animation blending, bone-attached cloth, outline quality. Use after a rigged GLB exists in character/.
tools: Read, Write, Edit, Bash, Glob, Grep
---
Read src/player/avatar.js. Steps:
1. `npm run optimize:hero` (character/ronin-rigged.glb -> public/models/ronin.glb + manifest).
2. Run the game; check facing (+Z). If backwards set HERO.yawOffset = Math.PI.
3. Verify clip mapping in qa/report.json (`clips`). Rename regexes in avatar.js only if a clip is unmapped.
4. Attach ribbons to real bones: scarf at neck/upper-chest, sash tail at hips, optional hat cords at head.
   Tune Ribbon length/width/wind/damping so it trails on run and settles in < 1 s at idle.
5. Foot sliding: match walk/run timeScale to speed. Report the numbers you chose.

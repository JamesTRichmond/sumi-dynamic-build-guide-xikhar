import { defineConfig } from 'vite';
// base './' lets the same build run on Vercel, GitHub Pages sub-paths, or a file server.
export default defineConfig({ base: './', build: { target: 'es2022', chunkSizeWarningLimit: 1500 } });

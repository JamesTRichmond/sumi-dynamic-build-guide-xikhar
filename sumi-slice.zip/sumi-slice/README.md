# SUMI — ink-wash game starter (from the Dynamic Build Guide)

```bash
npm install
npm run dev        # open the printed URL. WASD, Shift, Space, click to look, F1 stats, F2 ink panel
npm run qa         # screenshots + movement tests + perf -> qa/report.json (needs Google Chrome)
```

Pipeline commands (each needs its inputs; see the guide):
| step | command | input -> output |
|---|---|---|
| reference video | `npm run gen:video` | reference/keyframe.png + video-prompt.txt -> reference/takes/*.mp4 |
| frames + palette | `npm run ref:frames` | reference/ref.mp4 -> reference/frames, contact-sheet, palette |
| turnaround | `npm run gen:views` | character/hero-crop.png -> character/turnaround.png |
| split views | `npm run split:views` | turnaround.png -> character/views/{front,left,back,right}.png |
| 3D mesh | `npm run gen:mesh` | views -> character/ronin-raw.glb |
| web hero | `npm run optimize:hero` | character/ronin-rigged.glb -> public/models/ronin.glb |

Keys go in `.env.local` (copy `.env.example`). Never commit it.

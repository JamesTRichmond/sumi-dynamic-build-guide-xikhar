#!/usr/bin/env bash
# Reference video -> frames (2/s), a contact sheet, and a 12-colour palette.
# Usage: npm run ref:frames   (expects reference/ref.mp4)
set -euo pipefail
IN="${1:-reference/ref.mp4}"
[ -f "$IN" ] || { echo "Missing $IN. Save your accepted clip there first."; exit 1; }
mkdir -p reference/frames
ffmpeg -hide_banner -loglevel error -y -i "$IN" -vf "fps=2" reference/frames/f_%03d.png
ffmpeg -hide_banner -loglevel error -y -i "$IN" -vf "fps=1,scale=480:-1,tile=4x3" -frames:v 1 reference/contact-sheet.png
ffmpeg -hide_banner -loglevel error -y -i "$IN" -vf "fps=4,palettegen=max_colors=12:reserve_transparent=0:stats_mode=full" reference/palette.png
echo "frames:        reference/frames/ ($(ls reference/frames | wc -l | tr -d ' ') files)"
echo "contact sheet: reference/contact-sheet.png"
echo "palette:       reference/palette.png"

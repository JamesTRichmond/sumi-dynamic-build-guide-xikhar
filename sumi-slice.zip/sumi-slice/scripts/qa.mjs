// Automated QA: boots the game in real Chrome, fails on console errors,
// screenshots every named shot, measures fps / draw calls / triangles,
// runs a scripted movement test, writes qa/report.json.
//   npm run qa                 -> all shots of level 0
//   npm run qa -- --headed     -> watch it happen
// Agents MUST run this and look at qa/shots/*.png before claiming visual work is done.
import { createServer } from 'vite';
import { chromium } from 'playwright-core';
import { mkdir, writeFile } from 'node:fs/promises';

const headed = process.argv.includes('--headed');
const W = 1600, H = 900;

const server = await createServer({ server: { port: 5199, strictPort: false }, logLevel: 'error' });
await server.listen();
const url = server.resolvedUrls.local[0];

const browser = await chromium.launch({
  channel: process.env.QA_CHROME_PATH ? undefined : 'chrome',
  executablePath: process.env.QA_CHROME_PATH || undefined,
  headless: !headed,
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: W, height: H } });
const consoleErrors = [];
page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
page.on('pageerror', (e) => consoleErrors.push(String(e)));

await page.goto(url);
await page.waitForFunction(() => window.__qa?.ready === true, null, { timeout: 60000 });
await mkdir('qa/shots', { recursive: true });

const report = { url, when: new Date().toISOString(), shots: [], movement: null, perf: null, errors: consoleErrors };
const shots = await page.evaluate(() => window.__qa.shots());
for (const name of shots) {
  await page.evaluate((n) => window.__qa.shot(n), name);
  await page.waitForTimeout(1200); // let ribbons settle and ink boil
  const file = `qa/shots/${name}.png`;
  await page.screenshot({ path: file });
  report.shots.push({ name, file, info: await page.evaluate(() => window.__qa.info()) });
}

// movement tests (deterministic, fixed 60 Hz, independent of headless frame rate)
await page.evaluate(() => window.__qa.shot('spawn'));
const settle = await page.evaluate(() => window.__qa.simulate(1));
const before = settle;
const walk = await page.evaluate(() => window.__qa.simulate(3, { y: 1 }));          // walk up the stair
const run = await page.evaluate(() => window.__qa.simulate(2, { y: 1, run: true }));
const jump = await page.evaluate(() => window.__qa.simulate(2, { jump: true }));     // jump in place, must land
const after = jump;
const moved = Math.hypot(run.pos[0] - before.pos[0], run.pos[2] - before.pos[2]);
const climbed = run.pos[1] - before.pos[1];
report.movement = {
  before, walk, run, jump, moved: +moved.toFixed(2), climbed: +climbed.toFixed(2),
  checks: { moved: moved > 8, climbedStairs: climbed > 1, jumpLeftGround: jump.leftGround, jumpLanded: jump.landed && jump.grounded, startedGrounded: settle.grounded },
};
report.movement.pass = Object.values(report.movement.checks).every(Boolean);

await page.waitForTimeout(1500);
report.perf = { fps: +(await page.evaluate(() => window.__qa.fps())).toFixed(1), ...(await page.evaluate(() => window.__qa.info())), note: headed ? 'headed' : 'headless software GL: fps here is NOT your real fps; read it in-game with F1' };

await writeFile('qa/report.json', JSON.stringify(report, null, 2));
await browser.close();
await server.close();

const fail = consoleErrors.length > 0 || !report.movement.pass;
console.log(`shots: ${report.shots.map((s) => s.file).join(', ')}`);
console.log(`movement: moved ${report.movement.moved}m, climbed ${report.movement.climbed}m, checks ${JSON.stringify(report.movement.checks)} -> ${report.movement.pass ? 'PASS' : 'FAIL'}`);
console.log(`perf: ${report.perf.calls} draw calls, ${(report.perf.triangles / 1000).toFixed(0)}k tris, avatar=${report.perf.avatar}`);
console.log(consoleErrors.length ? `console errors (${consoleErrors.length}):\n  ${consoleErrors.join('\n  ')}` : 'console errors: 0');
process.exit(fail ? 1 : 0);

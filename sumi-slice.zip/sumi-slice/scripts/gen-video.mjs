// FLUX 3 Max image-to-video on fal. Start frame + prompt -> reference/takes/take-<time>.mp4
// Needs FAL_KEY in .env.local. Inputs: reference/keyframe.png and reference/video-prompt.txt
// Billed per second of output. Draft at 720p (default); add --final for 1080p.
import { fal } from '@fal-ai/client';
import { readFile, writeFile, mkdir } from 'node:fs/promises';

if (!process.env.FAL_KEY) { console.error('FAL_KEY missing. Add it to .env.local'); process.exit(1); }
const resolution = process.argv.includes('--final') ? '1080p' : '720p';
const duration = 10;
const prompt = (await readFile('reference/video-prompt.txt', 'utf8')).trim();
const image = await readFile('reference/keyframe.png');
const image_url = await fal.storage.upload(new Blob([image], { type: 'image/png' }));

console.log(`Generating ${duration}s @ ${resolution} with FLUX 3 Max...`);
const result = await fal.subscribe('blackforestlabs/flux-3-max/image-to-video', {
  input: { prompt, image_url, duration, resolution, generate_audio: false },
  logs: true,
  onQueueUpdate: (u) => { if (u.status === 'IN_QUEUE') process.stdout.write('.'); },
});
const url = result.data?.video?.url;
if (!url) { console.error('\nNo video URL in response:', JSON.stringify(result.data).slice(0, 400)); process.exit(1); }
await mkdir('reference/takes', { recursive: true });
const out = `reference/takes/take-${new Date().toISOString().replace(/[:.]/g, '-')}.mp4`;
await writeFile(out, Buffer.from(await (await fetch(url)).arrayBuffer()));
console.log(`\nSaved ${out}  (request ${result.requestId})`);
console.log('Watch it. If accepted: cp it to reference/ref.mp4, then npm run ref:frames');

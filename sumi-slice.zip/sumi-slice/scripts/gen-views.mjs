// GPT Image: one clean character crop -> a 4-panel T-pose turnaround sheet.
// Needs OPENAI_API_KEY in .env.local. Input: character/hero-crop.png  Output: character/turnaround.png
// The ChatGPT app does the same job with the same prompt (no key needed); this script is for repeat runs.
import OpenAI, { toFile } from 'openai';
import { readFile, writeFile } from 'node:fs/promises';

if (!process.env.OPENAI_API_KEY) { console.error('OPENAI_API_KEY missing. Add it to .env.local'); process.exit(1); }
const client = new OpenAI();
const model = process.env.IMAGE_MODEL || 'gpt-image-2.6-sunburst';
const prompt = (await readFile('character/turnaround-prompt.txt', 'utf8')).trim();
const img = await toFile(await readFile('character/hero-crop.png'), 'hero-crop.png', { type: 'image/png' });

console.log(`Requesting turnaround from ${model}...`);
const res = await client.images.edit({ model, image: img, prompt, size: '1536x1024', quality: 'high', n: 1 });
const b64 = res.data?.[0]?.b64_json;
if (!b64) { console.error('No image returned:', JSON.stringify(res).slice(0, 400)); process.exit(1); }
await writeFile('character/turnaround.png', Buffer.from(b64, 'base64'));
console.log('Saved character/turnaround.png -> check all 4 panels, then: npm run split:views');

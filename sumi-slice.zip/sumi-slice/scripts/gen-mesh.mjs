// Tripo H3.1 multiview -> 3D on fal. 4 views -> character/ronin-raw.glb
// Needs FAL_KEY. Inputs: character/views/{front,left,back,right}.png
// Prints the Tripo task_id: keep it, Tripo's rig step accepts it.
import { fal } from '@fal-ai/client';
import { readFile, writeFile } from 'node:fs/promises';

if (!process.env.FAL_KEY) { console.error('FAL_KEY missing. Add it to .env.local'); process.exit(1); }
const order = ['front', 'left', 'back', 'right']; // fal/Tripo expects exactly this order
const image_urls = [];
for (const v of order) {
  const buf = await readFile(`character/views/${v}.png`);
  image_urls.push(await fal.storage.upload(new Blob([buf], { type: 'image/png' })));
}
const faceLimit = Number(process.env.FACE_LIMIT || 30000); // web budget: 15k-40k for a hero
console.log(`Tripo H3.1 multiview, face_limit ${faceLimit}...`);
const result = await fal.subscribe('tripo3d/h3.1/multiview-to-3d', {
  input: { image_urls, face_limit: faceLimit, texture: true, pbr: false, texture_quality: 'detailed', auto_size: true },
  logs: true,
  onQueueUpdate: (u) => { if (u.status === 'IN_QUEUE') process.stdout.write('.'); },
});
const url = result.data?.model_mesh?.url;
if (!url) { console.error('\nNo mesh in response:', JSON.stringify(result.data).slice(0, 400)); process.exit(1); }
await writeFile('character/ronin-raw.glb', Buffer.from(await (await fetch(url)).arrayBuffer()));
console.log(`\nSaved character/ronin-raw.glb  tripo task_id: ${result.data.task_id ?? '(none returned)'}`);

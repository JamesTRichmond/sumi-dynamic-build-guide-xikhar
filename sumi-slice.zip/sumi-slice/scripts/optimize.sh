#!/usr/bin/env bash
# Rigged hero GLB -> web-ready GLB (meshopt geometry + webp textures, skeleton-safe flags).
set -euo pipefail
IN="${1:-character/ronin-rigged.glb}"
OUT="${2:-public/models/ronin.glb}"
[ -f "$IN" ] || { echo "Missing $IN"; exit 1; }
npx --yes @gltf-transform/cli@4 optimize "$IN" "$OUT" \
  --compress meshopt --texture-compress webp --texture-size 1024 \
  --flatten false --join false --palette false --simplify false
npx --yes @gltf-transform/cli@4 inspect "$OUT" | head -40
printf '{ "hero": "%s" }\n' "$(basename "$OUT")" > public/models/manifest.json
echo "Wrote $OUT and pointed public/models/manifest.json at it. Run: npm run dev"

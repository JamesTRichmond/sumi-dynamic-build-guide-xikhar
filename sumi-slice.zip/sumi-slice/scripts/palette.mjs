// Prints the reference palette as hex, darkest -> lightest, with value (0-100).
// Paste the result into docs/style-bible.md and src/config.js (INK.paper / ink / vermilion).
import { spawnSync } from 'node:child_process';
const r = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', 'reference/palette.png', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], { maxBuffer: 1 << 20 });
if (r.status !== 0) { console.error('Run "npm run ref:frames" first (needs reference/palette.png).'); process.exit(1); }
const px = r.stdout, seen = new Map();
for (let i = 0; i + 2 < px.length; i += 3) {
  const hex = '#' + [px[i], px[i + 1], px[i + 2]].map((v) => v.toString(16).padStart(2, '0')).join('');
  seen.set(hex, (seen.get(hex) ?? 0) + 1);
}
const lum = (h) => { const n = parseInt(h.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 2.55; };
const sat = (h) => { const n = parseInt(h.slice(1), 16); const c = [n >> 16, (n >> 8) & 255, n & 255]; const mx = Math.max(...c), mn = Math.min(...c); return mx ? (mx - mn) / mx : 0; };
const list = [...seen.keys()].sort((a, b) => lum(a) - lum(b));
for (const h of list) console.log(`${h}  value ${lum(h).toFixed(0).padStart(3)}  sat ${(sat(h) * 100).toFixed(0).padStart(3)}%${sat(h) > 0.35 ? '  <- accent candidate (vermilion?)' : ''}`);
console.log(`\nSuggested: INK.ink = ${list[0]}  INK.paper = ${list[list.length - 1]}`);

#!/usr/bin/env bash
# Splits a 4-panel horizontal turnaround (front | left | back | right) into 4 square, padded PNGs.
set -euo pipefail
IN="${1:-character/turnaround.png}"
[ -f "$IN" ] || { echo "Missing $IN"; exit 1; }
mkdir -p character/views
i=0
for v in front left back right; do
  ffmpeg -hide_banner -loglevel error -y -i "$IN" \
    -vf "crop=iw/4:ih:iw/4*$i:0,pad=max(iw\,ih):max(iw\,ih):(ow-iw)/2:(oh-ih)/2:color=0xD9D9D9" \
    "character/views/$v.png"
  i=$((i+1))
done
ls -1 character/views

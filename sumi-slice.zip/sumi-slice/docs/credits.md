# Credits and rights (fill before every release: X04)

| Asset | Made with / source | Terms link | Commercial use OK? | Notes |
|---|---|---|---|---|
| reference/keyframe.png | GPT Image (OpenAI) | | | reference only, not shipped |
| reference/ref.mp4 | FLUX 3 Max on fal | | | reference only, not shipped |
| public/models/ronin.glb | GPT Image views -> Tripo H3.1 (fal) -> Tripo rig | | | shipped |
| code | Claude Code + you | | | your repo licence |

No real people, no trademarked characters, no assets copied from other games.

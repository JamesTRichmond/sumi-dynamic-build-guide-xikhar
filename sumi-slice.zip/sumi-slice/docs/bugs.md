# Bug log (play -> report -> agents fix -> replay)

Template (one per bug; agents fix top-down by severity):
### B-001 · [S1 blocker | S2 major | S3 minor] · level: shrine-stairs
- Saw:
- Did (exact input, where):
- Expected:
- Evidence: qa/shots/... or screen recording path
- Status: open | fixed in <branch> | verified by human on <date>

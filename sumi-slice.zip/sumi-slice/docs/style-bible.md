# Style bible — SUMI (the lock)

Fill from reference/frames and `npm run ref:frames` output. Every line must be checkable.

## Palette (hex, from scripts/palette.mjs)
- Paper:
- Ink (darkest):
- Mid stone:
- Vermilion (only accent):
- Forbidden: any other saturated colour.

## Values
- Sky + mist: 85-100 value. Near stone: 55-85. Pines + robe: 10-30. Ink lines: darkest.

## Line
- Weight at 5 m:      Lines fade fully by:      Boil (fps):

## Camera
- Third-person chase. FOV:   Distance:   Look-at height:   Default pitch:

## Silhouette (hero)
- Wide conical straw kasa · dark layered robe · vermilion sash · pale trailing scarf · katana on left hip · gourd at right hip.

## World grammar
- Stone stairs, torii, stone lanterns, bonsai pines with flat cloud canopies, karst pillars, sea of clouds, red sun.

## Forbidden
- Second art style · second protagonist · bloom/glow · photoreal textures · UI that is not ink on paper.

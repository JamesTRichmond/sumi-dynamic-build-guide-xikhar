# Level NN — <name>
- Concept boards: concept/NN-*.png (max 8; list which ones were KEPT)
- One-sentence verb:
- Beats (30-90 s each): 1) arrive  2) learn  3) test  4) vista / exit
- Landmark visible from spawn:
- Signature mechanic + config block:
- Asset list (reuse first):
- Exit / transition:
- Done when: qa passes · shots match boards (mismatches listed) · a human played it start to exit

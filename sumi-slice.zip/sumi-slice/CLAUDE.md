# SUMI — project rules for every agent

You are building a browser game in the ink-wash (sumi-e) style: a wandering ronin climbs
a mountain of ink toward a red sun. three.js r187+, Vite, plain JavaScript (ES modules).

## The lock (never break it)
- `docs/style-bible.md` and `reference/` define the look. They win every argument.
- Values first: paper `INK.paper`, ink `INK.ink`. The ONLY saturated hue is vermilion (`INK.vermilion`):
  torii, sash, sun, blood-of-the-story moments. Never add a second accent colour.
- One protagonist. One art style. No new genre. No UI chrome that is not ink on paper.
- Tunables live in `src/config.js`. Do not scatter magic numbers.

## Architecture (read before editing)
- `src/ink/InkRenderer.js` — 3-pass render: colour+depth, view normals (layer 0 only), ink composite.
  Layer 0 = solid geometry (gets lines). Layer 1 = sky/mist (no lines, no normals).
- `src/world/levels/*.js` — one file per level, each returns the level contract (see LevelManager.js).
  Call `bakeStatic(group)` at the end of every builder: hidden originals stay as colliders.
- `src/player/controller.js` — kinematic raycast controller. Colliders are plain meshes.
- `src/player/avatar.js` — placeholder or GLB hero (via `public/models/manifest.json`). Same contract.
- `src/player/cloth.js` — verlet ribbons for scarf/sash/hat cords.
- `window.__qa` — stable hooks for automated QA. Never remove; extend.

## Definition of done (all must be true before you say "done")
1. `npm run qa` exits 0 (no console errors, movement checks pass).
2. You opened every `qa/shots/*.png` and compared it with the matching `reference/frames/*` image,
   and you wrote the remaining mismatches in your reply (palette, line weight, silhouette, fog).
3. Draw calls < 150 and triangles < 600k on the level you touched (see qa/report.json).
4. You did not change files outside your assignment. If you needed to, say so instead.
5. Human-only gates are not yours to clear: "feel is good", "music works", "level is fun".

## Git
- Work on a branch named `agent/<task-id>-<slug>`. Small commits. Never push to main. Open a PR.

## Budget
- Ask before adding any dependency. Prefer code over assets. Prefer procedural over downloaded.

import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

/**
 * Draw-call killer. Merges every static mesh in `group` into one mesh per material.
 * Originals stay in the scene graph but hidden: they remain valid raycast colliders
 * (Raycaster ignores .visible), keeping per-object bounding-sphere culling for physics.
 * Skip anything with userData.dynamic = true (animated props, triggers).
 */
export function bakeStatic(group) {
  group.updateMatrixWorld(true);
  const buckets = new Map();
  group.traverse((o) => {
    if (!o.isMesh || o.isSkinnedMesh || o.userData.dynamic || o.layers.mask !== 1) return;
    if (Array.isArray(o.material)) return;
    let g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
    for (const name of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(name)) g.deleteAttribute(name);
    if (!g.attributes.uv) g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2));
    if (!g.attributes.normal) g.computeVertexNormals();
    g.applyMatrix4(o.matrixWorld);
    const key = o.material.uuid;
    if (!buckets.has(key)) buckets.set(key, { material: o.material, geos: [], cast: false, receive: false });
    const b = buckets.get(key);
    b.geos.push(g); b.cast ||= o.castShadow; b.receive ||= o.receiveShadow;
    o.visible = false;
  });
  const baked = new THREE.Group();
  baked.name = 'baked-static';
  for (const b of buckets.values()) {
    const merged = mergeGeometries(b.geos, false);
    for (const g of b.geos) g.dispose();
    const mesh = new THREE.Mesh(merged, b.material);
    mesh.castShadow = b.cast; mesh.receiveShadow = b.receive;
    mesh.matrixAutoUpdate = false;
    baked.add(mesh);
  }
  // baked meshes live in world space; group must be identity-transformed
  group.add(baked);
  return baked;
}

import * as THREE from 'three';
import { toon, PALETTE } from '../ink/materials.js';

/** Deterministic RNG so every agent and every screenshot sees the same world. */
export function rng(seed = 1) {
  let s = seed >>> 0;
  return () => { s = (s + 0x6d2b79f5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

function displace(geo, amount, rand, freq = 1.3) {
  const p = geo.attributes.position;
  const v = new THREE.Vector3();
  const o1 = rand() * 100, o2 = rand() * 100;
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i);
    const n = Math.sin(v.x * freq + o1) * Math.cos(v.z * freq * 1.3 + o2) * Math.sin(v.y * freq * 0.7 + o1 * 0.5);
    v.multiplyScalar(1 + n * amount);
    v.y *= 0.82; // boulders sit, they don't float
    p.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();
  return geo;
}

export function rock(rand, size = 1, tone = PALETTE.stone) {
  const geo = displace(new THREE.IcosahedronGeometry(size, 1), 0.28, rand);
  const m = new THREE.Mesh(geo, toon(tone, { flat: true }));
  m.rotation.set(rand() * 0.6, rand() * Math.PI * 2, rand() * 0.6);
  m.castShadow = m.receiveShadow = true;
  return m;
}

/** Karst pillar: the tall stacked cliffs of shan-shui painting. */
export function pillar(rand, height = 30, radius = 5) {
  const geo = new THREE.CylinderGeometry(radius * 0.75, radius, height, 9, 8);
  const p = geo.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i);
    const k = 1 + Math.sin(v.y * 0.35 + rand() * 0.2) * 0.12 + (rand() - 0.5) * 0.18;
    p.setXYZ(i, v.x * k, v.y, v.z * k);
  }
  geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, toon(PALETTE.stone, { flat: true }));
  m.castShadow = m.receiveShadow = true;
  return m;
}

/** Bonsai-style pine: bent trunk + flat cloud-canopies (the sumi-e pine silhouette). */
export function pine(rand, scale = 1) {
  const g = new THREE.Group();
  const pts = [];
  let x = 0, z = 0;
  const lean = (rand() - 0.5) * 1.4;
  for (let i = 0; i <= 6; i++) { x += lean * 0.25 + (rand() - 0.5) * 0.3; z += (rand() - 0.5) * 0.3; pts.push(new THREE.Vector3(x, i * 0.7, z)); }
  const curve = new THREE.CatmullRomCurve3(pts);
  const trunk = new THREE.Mesh(new THREE.TubeGeometry(curve, 16, 0.16, 6, false), toon(PALETTE.bark));
  trunk.castShadow = true;
  g.add(trunk);
  const pads = 3 + Math.floor(rand() * 3);
  for (let i = 0; i < pads; i++) {
    const t = 0.45 + (i / pads) * 0.55;
    const at = curve.getPoint(t);
    const pad = new THREE.Mesh(new THREE.SphereGeometry(1, 9, 5), toon(PALETTE.pine, { flat: true }));
    const r = 1.1 + rand() * 0.9 - i * 0.12;
    pad.scale.set(r * 1.5, r * 0.32, r * 1.1);
    pad.position.set(at.x + (rand() - 0.5) * 1.6, at.y + 0.2, at.z + (rand() - 0.5) * 1.2);
    pad.rotation.y = rand() * Math.PI;
    pad.castShadow = true;
    g.add(pad);
  }
  g.scale.setScalar(scale);
  return g;
}

/** Torii gate, built to real proportions (pillar ~ 1/10 of height). */
export function torii(height = 6, width = 5.2) {
  const g = new THREE.Group();
  const red = toon(PALETTE.vermilion);
  const black = toon('#1d1b19');
  const r = height * 0.055;
  for (const sx of [-1, 1]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.12, height, 14), red);
    post.position.set(sx * width / 2, height / 2, 0);
    post.rotation.z = -sx * 0.025; // slight inward lean, as real torii have
    const base = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.35, r * 1.35, height * 0.07, 14), black);
    base.position.set(sx * width / 2, height * 0.035, 0);
    g.add(post, base);
  }
  const nuki = new THREE.Mesh(new THREE.BoxGeometry(width * 1.18, height * 0.07, r * 1.3), red);
  nuki.position.y = height * 0.74;
  // kasagi: top beam with upswept ends, from a bent box
  const kGeo = new THREE.BoxGeometry(width * 1.5, height * 0.08, r * 2.4, 24, 1, 1);
  const p = kGeo.attributes.position;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i) / (width * 0.75); p.setY(i, p.getY(i) + x * x * x * x * height * 0.06); }
  kGeo.computeVertexNormals();
  const kasagi = new THREE.Mesh(kGeo, black);
  kasagi.position.y = height * 0.97;
  const shimaki = new THREE.Mesh(new THREE.BoxGeometry(width * 1.38, height * 0.06, r * 2.0), red);
  shimaki.position.y = height * 0.9;
  const plaque = new THREE.Mesh(new THREE.BoxGeometry(width * 0.16, height * 0.13, r * 0.6), black);
  plaque.position.y = height * 0.82;
  g.add(nuki, kasagi, shimaki, plaque);
  g.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  return g;
}

/** Stone lantern (tōrō). */
export function lantern() {
  const g = new THREE.Group();
  const m = toon(PALETTE.lantern, { flat: true });
  const parts = [
    [new THREE.CylinderGeometry(0.28, 0.34, 0.15, 6), 0.075],
    [new THREE.CylinderGeometry(0.1, 0.12, 0.7, 6), 0.5],
    [new THREE.CylinderGeometry(0.3, 0.22, 0.12, 6), 0.9],
    [new THREE.BoxGeometry(0.32, 0.3, 0.32), 1.11],
    [new THREE.ConeGeometry(0.42, 0.28, 6), 1.4],
    [new THREE.SphereGeometry(0.07, 6, 4), 1.58],
  ];
  for (const [geo, y] of parts) { const mesh = new THREE.Mesh(geo, m); mesh.position.y = y; mesh.castShadow = true; g.add(mesh); }
  return g;
}

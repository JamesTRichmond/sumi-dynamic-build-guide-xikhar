import * as THREE from 'three';
import { LAYER_ATMOS } from '../ink/InkRenderer.js';
import { INK, WORLD } from '../config.js';

const NOISE = /* glsl */ `
  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float noise(vec2 p) { vec2 i = floor(p), f = fract(p); vec2 u = f*f*(3.0-2.0*f);
    return mix(mix(hash(i), hash(i+vec2(1,0)), u.x), mix(hash(i+vec2(0,1)), hash(i+vec2(1,1)), u.x), u.y); }
  float fbm(vec2 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 6; i++) { v += a*noise(p); p *= 2.02; a *= 0.5; } return v; }
`;

/** Painted sky: paper gradient + vermilion cloud wash + optional red sun. */
export function makeSky({ sun = true } = {}) {
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      paper: { value: new THREE.Color(INK.paper) },
      top: { value: new THREE.Color('#cfc5ae') },
      red: { value: new THREE.Color(INK.vermilion) },
      sunDir: { value: new THREE.Vector3(0.35, 0.18, -1).normalize() },
      sunOn: { value: sun ? 1 : 0 },
      time: { value: 0 },
    },
    vertexShader: /* glsl */ `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position.z = gl_Position.w; }`,
    fragmentShader: /* glsl */ `
      uniform vec3 paper, top, red, sunDir; uniform float sunOn, time; varying vec3 vDir;
      ${NOISE}
      void main(){
        vec3 d = normalize(vDir);
        float h = clamp(d.y, -0.2, 1.0);
        vec3 col = mix(paper, top, smoothstep(0.0, 0.9, h));
        // long horizontal brush-wash clouds
        vec2 p = vec2(atan(d.z, d.x) * 2.2, d.y * 9.0);
        float c = fbm(p * vec2(1.0, 1.6) + vec2(time * 0.004, 0.0));
        float band = smoothstep(0.08, 0.25, h) * (1.0 - smoothstep(0.35, 0.7, h));
        float cloud = smoothstep(0.52, 0.78, c) * band;
        col = mix(col, red * 1.05, cloud * 0.55);
        // sun: a flat vermilion disc, the only hard-edged thing in the sky
        float s = dot(d, normalize(sunDir));
        col = mix(col, red, sunOn * smoothstep(0.9965, 0.9975, s));
        gl_FragColor = vec4(col, 1.0);
        #include <colorspace_fragment>
      }`,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 48, 24), mat);
  sky.layers.set(LAYER_ATMOS);
  sky.frustumCulled = false;
  sky.renderOrder = -10;
  return sky;
}

/** Mist: soft noise cards. Horizontal sea-of-clouds + vertical drifting veils. */
export function makeMist({ seaLevel = -6, extent = 600, cards = [] } = {}) {
  const group = new THREE.Group();
  const mats = [];
  const make = (opacity, scale, speed) => {
    const m = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, fog: false, side: THREE.DoubleSide,
      uniforms: { color: { value: new THREE.Color(INK.paper) }, time: { value: 0 }, opacity: { value: opacity }, scale: { value: scale }, speed: { value: speed } },
      vertexShader: /* glsl */ `varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
      fragmentShader: /* glsl */ `
        uniform vec3 color; uniform float time, opacity, scale, speed; varying vec2 vUv; varying vec3 vW;
        ${NOISE}
        void main(){
          vec2 p = vW.xz * scale + vec2(time * speed, time * speed * 0.3);
          float n = fbm(p) * 0.65 + fbm(p * 2.7 + 11.0) * 0.35;
          float edge = smoothstep(0.0, 0.25, vUv.x) * smoothstep(1.0, 0.75, vUv.x) * smoothstep(0.0, 0.25, vUv.y) * smoothstep(1.0, 0.75, vUv.y);
          float a = smoothstep(0.38, 0.75, n) * edge * opacity;
          gl_FragColor = vec4(color, a);
          #include <colorspace_fragment>
        }`,
    });
    mats.push(m);
    return m;
  };

  // sea of clouds: stacked horizontal layers below the playable area
  for (let i = 0; i < WORLD.mistLayers; i++) {
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(extent, extent), make(0.75 - i * 0.06, 0.012 + i * 0.002, 0.6 + i * 0.25));
    plane.rotation.x = -Math.PI / 2;
    plane.position.y = seaLevel - i * 1.6;
    plane.layers.set(LAYER_ATMOS);
    plane.renderOrder = 1;
    group.add(plane);
  }
  // vertical veils (world-space noise uses xz, so rotate the sample by using a tall plane)
  for (const c of cards) {
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(c.w, c.h), make(c.opacity ?? 0.45, 0.06, 0.9));
    plane.position.set(c.x, c.y, c.z);
    plane.rotation.y = c.ry ?? 0;
    plane.rotation.x = -Math.PI / 2 + 0.0001; // treat as horizontal veil at that height
    plane.layers.set(LAYER_ATMOS);
    plane.renderOrder = 2;
    group.add(plane);
  }
  group.userData.update = (t) => { for (const m of mats) m.uniforms.time.value = t; };
  return group;
}

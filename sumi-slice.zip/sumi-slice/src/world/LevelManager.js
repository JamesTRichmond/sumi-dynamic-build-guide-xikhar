import { buildShrineStairs } from './levels/shrineStairs.js';

/**
 * Level registry. Each level module exports a builder returning:
 *   { id, title, group, colliders[], spawn:Vector3, spawnYaw, exit:Box3|null, update(t), shots{} }
 * Add a level = add a file in ./levels and one line here. Order = play order.
 */
export const LEVELS = [
  buildShrineStairs,
  // buildRopeBridge,
  // buildWindRidge,
  // buildShadowCourtyard,
  // buildBlackLake,
  // buildSnowAscent,
  // buildMonolithPlain,
  // buildRedSun,
];

export class LevelManager {
  constructor(scene) { this.scene = scene; this.index = -1; this.level = null; }

  load(index) {
    if (this.level) {
      this.scene.remove(this.level.group);
      this.level.group.traverse((o) => { o.geometry?.dispose?.(); });
    }
    this.index = (index + LEVELS.length) % LEVELS.length;
    this.level = LEVELS[this.index]();
    this.scene.add(this.level.group);
    this.level.group.updateMatrixWorld(true);
    return this.level;
  }

  next() { return this.load(this.index + 1); }
}

import * as THREE from 'three';
import { toon, PALETTE } from '../../ink/materials.js';
import { rng, rock, pillar, pine, torii, lantern } from '../props.js';
import { makeMist } from '../atmosphere.js';
import { bakeStatic } from '../bake.js';

/**
 * Level 1 — "Shrine Stairs". The reference shot from the thread:
 * a stone stair climbing a cliff to a torii above a sea of clouds.
 * Every level module returns the same contract (see LevelManager).
 */
export function buildShrineStairs() {
  const rand = rng(7);
  const group = new THREE.Group();
  const colliders = [];
  const solid = (mesh) => { group.add(mesh); colliders.push(mesh); return mesh; };

  // ---- start ledge
  const start = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 4.2, 3, 10), toon(PALETTE.stoneLight, { flat: true }));
  start.position.set(0, -1.5, 2);
  start.receiveShadow = true;
  solid(start);

  // ---- the stair: steps placed along a curve, with landings
  const path = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, -1.5), new THREE.Vector3(1.8, 0, -12), new THREE.Vector3(-1.2, 0, -24),
    new THREE.Vector3(0.6, 0, -36), new THREE.Vector3(0, 0, -44),
  ]);
  const STEPS = 64, RISE = 0.27;
  let y = 0;
  const stepMat = toon(PALETTE.stoneLight, { flat: true });
  const stepMatB = toon(PALETTE.stone, { flat: true });
  for (let i = 0; i < STEPS; i++) {
    const t = i / (STEPS - 1);
    const landing = i % 16 >= 13; // three flat treads every 16
    if (!landing) y += RISE;
    const p = path.getPointAt(t);
    const tan = path.getTangentAt(t);
    const w = 2.8 + rand() * 0.4;
    const depthBelow = 1.2 + i * 0.02;
    const step = new THREE.Mesh(new THREE.BoxGeometry(w, depthBelow, 0.78), rand() > 0.3 ? stepMat : stepMatB);
    step.position.set(p.x + (rand() - 0.5) * 0.08, y - depthBelow / 2, p.z);
    step.rotation.y = Math.atan2(tan.x, tan.z) + (rand() - 0.5) * 0.05;
    step.castShadow = step.receiveShadow = true;
    solid(step);
    // cliff wall on the right, broken rocks on the left
    if (i % 4 === 0) {
      const side = new THREE.Vector3(tan.z, 0, -tan.x).normalize();
      const r1 = rock(rand, 0.8 + rand() * 0.9, rand() > 0.6 ? PALETTE.stone : PALETTE.stoneLight);
      r1.position.copy(p).addScaledVector(side, -(w / 2 + 1.1 + rand() * 0.8)).setY(y + rand() * 0.6);
      solid(r1);
      if (rand() > 0.5) {
        const r2 = rock(rand, 0.35 + rand() * 0.4, PALETTE.stoneLight);
        r2.position.copy(p).addScaledVector(side, w / 2 + 0.5 + rand() * 0.4).setY(y - 0.2);
        solid(r2);
      }
    }
  }
  const top = y;

  // ---- right-hand cliff mass (the big grey wall in the reference)
  for (let i = 0; i < 6; i++) {
    const c = pillar(rand, 16 + rand() * 18, 4 + rand() * 3);
    const t = i / 5;
    const p = path.getPointAt(Math.min(t, 1));
    c.position.set(p.x - 8 - rand() * 3, top * t - 2, p.z + (rand() - 0.5) * 4);
    solid(c);
  }

  // ---- summit platform, torii, lanterns, guardian pine
  const summitPos = path.getPointAt(1).clone().setY(top);
  const summit = new THREE.Mesh(new THREE.CylinderGeometry(7, 6, 4, 12), toon(PALETTE.stoneLight, { flat: true }));
  summit.position.set(summitPos.x, top - 2, summitPos.z - 5);
  summit.receiveShadow = true;
  solid(summit);
  const gate = torii(6.4, 5.4);
  gate.position.set(summitPos.x, top, summitPos.z - 5);
  group.add(gate);
  for (const sx of [-1, 1]) {
    const l = lantern();
    l.position.set(summitPos.x + sx * 3.6, top, summitPos.z - 1.8);
    group.add(l);
  }
  const guardian = pine(rand, 1.4);
  guardian.position.set(summitPos.x + 6.5, top, summitPos.z - 10);
  group.add(guardian);

  // ---- distant shan-shui: karst pillars with pines, fading into mist
  for (let i = 0; i < 26; i++) {
    const a = rand() * Math.PI * 1.6 + Math.PI * 0.2;
    const d = 45 + rand() * 120;
    const h = 20 + rand() * 45;
    const c = pillar(rand, h, 3 + rand() * 6);
    c.position.set(Math.cos(a) * d, -14 + h / 2 - rand() * 6, Math.sin(a) * d - 30);
    group.add(c);
    if (rand() > 0.35) {
      const pn = pine(rand, 1 + rand() * 1.5);
      pn.position.set(c.position.x, c.position.y + h / 2 - 0.3, c.position.z);
      group.add(pn);
    }
  }
  for (let i = 0; i < 8; i++) {
    const pn = pine(rand, 0.9 + rand() * 0.6);
    const p = path.getPointAt(0.1 + rand() * 0.8);
    pn.position.set(p.x - 3.5 - rand() * 2, top * (0.1 + rand() * 0.7), p.z);
    group.add(pn);
  }

  // ---- far ranges: layered peaks that aerial perspective turns into ink-wash bands
  for (let ring = 0; ring < 3; ring++) {
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2 + rand() * 0.3;
      const d = 95 + ring * 55 + rand() * 25;
      const h = 30 + rand() * 40 + ring * 12;
      const peak = new THREE.Mesh(new THREE.ConeGeometry(18 + rand() * 22, h, 7, 4), toon(ring === 0 ? PALETTE.stone : PALETTE.stoneLight, { flat: true }));
      const pp = peak.geometry.attributes.position;
      for (let k = 0; k < pp.count; k++) { const yy = pp.getY(k); if (yy < h / 2 - 0.1) { pp.setX(k, pp.getX(k) * (0.8 + rand() * 0.4)); pp.setZ(k, pp.getZ(k) * (0.8 + rand() * 0.4)); } }
      peak.geometry.computeVertexNormals();
      peak.position.set(Math.cos(a) * d, -26 + h / 2, Math.sin(a) * d - 25);
      peak.rotation.y = rand() * Math.PI;
      group.add(peak);
    }
  }

  // ---- atmosphere
  const mist = makeMist({ seaLevel: -7, cards: [
    { x: 8, y: 4, z: -18, w: 40, h: 40, opacity: 0.35 },
    { x: -14, y: 9, z: -34, w: 50, h: 50, opacity: 0.3 },
  ] });
  group.add(mist);

  bakeStatic(group);

  const exit = new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(summitPos.x, top + 1.5, summitPos.z - 5), new THREE.Vector3(4.6, 3, 1.2));

  return {
    id: 'shrine-stairs',
    title: 'I · The Shrine Stairs',
    group,
    colliders,
    spawn: new THREE.Vector3(0, 0.05, 2.5),
    spawnYaw: Math.PI, // face up the stair (-z)
    exit,
    update: (t) => mist.userData.update(t),
    // named camera shots for QA screenshots: [player position, yaw, pitch]
    shots: {
      spawn: { pos: [0, 0.05, 2.5], yaw: Math.PI, pitch: 0.18 },
      'mid-stairs': { pos: [path.getPointAt(0.45).x, top * 0.45 + 0.1, path.getPointAt(0.45).z], yaw: Math.PI - 0.15, pitch: 0.25 },
      summit: { pos: [summitPos.x, top + 0.05, summitPos.z + 3], yaw: Math.PI, pitch: 0.12 },
    },
  };
}

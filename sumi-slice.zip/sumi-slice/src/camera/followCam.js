import * as THREE from 'three';
import { CAM } from '../config.js';

const _target = new THREE.Vector3();
const _desired = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _ray = new THREE.Raycaster();

/**
 * Third-person orbit camera with a spring arm:
 *  - mouse / right-stick orbit, pitch clamped
 *  - auto-recenters behind the player after idle look input (the "chase cam" in the reference video)
 *  - pulls in when geometry blocks the view
 */
export class FollowCam {
  constructor(aspect) {
    this.camera = new THREE.PerspectiveCamera(CAM.fov, aspect, 0.1, 1200);
    this.yaw = 0;
    this.pitch = CAM.pitch;
    this.armLength = CAM.distance;
    this.sinceLook = 99;
    this.colliders = [];
    this.focus = new THREE.Vector3();
  }

  snapBehind(playerPos, facing) {
    this.yaw = facing + Math.PI;
    this.pitch = CAM.pitch;
    this.focus.copy(playerPos).y += CAM.height;
    this.armLength = CAM.distance;
    this.place(1);
  }

  update(dt, intent, player) {
    this.yaw -= intent.lookX * CAM.sensitivity + intent.stickX * CAM.stickSensitivity * dt;
    this.pitch += intent.lookY * CAM.sensitivity + intent.stickY * CAM.stickSensitivity * dt;
    this.pitch = THREE.MathUtils.clamp(this.pitch, CAM.minPitch, CAM.maxPitch);
    this.sinceLook = intent.lookActive ? 0 : this.sinceLook + dt;

    // recenter behind the direction of travel when the player isn't steering the camera
    if (this.sinceLook > CAM.recenterDelay && player.horizontalSpeed > 0.5) {
      const behind = player.facing + Math.PI;
      let d = behind - this.yaw;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      this.yaw += d * Math.min(1, CAM.recenterSpeed * dt);
      this.pitch = THREE.MathUtils.damp(this.pitch, CAM.pitch, CAM.recenterSpeed, dt);
    }

    _target.copy(player.position).y += CAM.height;
    this.focus.lerp(_target, 1 - Math.exp(-CAM.followLag * dt));
    this.place(dt);
  }

  place(dt) {
    _dir.set(Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), Math.cos(this.yaw) * Math.cos(this.pitch));
    // shoulder offset, perpendicular to view
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw)).multiplyScalar(CAM.shoulder);
    const pivot = _target.copy(this.focus).add(right);
    // spring arm collision
    _ray.set(pivot, _dir);
    _ray.far = CAM.distance;
    const hit = this.colliders.length ? _ray.intersectObjects(this.colliders, false)[0] : null;
    const want = hit ? Math.max(0.6, hit.distance - CAM.collisionPad) : CAM.distance;
    // pull in fast, ease out slow (prevents popping)
    this.armLength = want < this.armLength ? want : THREE.MathUtils.damp(this.armLength, want, 3, dt);
    _desired.copy(pivot).addScaledVector(_dir, this.armLength);
    this.camera.position.copy(_desired);
    this.camera.lookAt(pivot);
  }
}

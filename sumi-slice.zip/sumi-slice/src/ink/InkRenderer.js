import * as THREE from 'three';
import { INK } from '../config.js';

// Layer convention:
//   0 = solid geometry (gets ink lines, writes normals)
//   1 = atmosphere: sky dome, mist cards (colour pass only, no lines)
export const LAYER_SOLID = 0;
export const LAYER_ATMOS = 1;

const FULLSCREEN_VERT = /* glsl */ `
  varying vec2 vUv;
  void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

const INK_FRAG = /* glsl */ `
  #include <packing>
  precision highp float;
  uniform sampler2D tColor;
  uniform sampler2D tDepth;
  uniform sampler2D tNormal;
  uniform vec2 resolution;
  uniform float cameraNear, cameraFar, time;
  uniform vec3 paper, ink, vermilion;
  uniform float toneSteps, toneSoftness, contrast;
  uniform float edgeDepth, edgeNormal, edgeThreshold, lineWidth, lineFadeFar;
  uniform float wobble, boilFps, grain, fogNear, fogFar, vermilionKeep, vignette;
  varying vec2 vUv;

  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
  }
  float fbm(vec2 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 5; i++) { v += a * noise(p); p *= 2.03; a *= 0.5; } return v; }

  float viewDist(vec2 uv) {
    float d = texture2D(tDepth, uv).x;
    return -perspectiveDepthToViewZ(d, cameraNear, cameraFar);
  }
  vec3 nrm(vec2 uv) { return texture2D(tNormal, uv).xyz * 2.0 - 1.0; }

  void main() {
    float boil = boilFps > 0.0 ? floor(time * boilFps) : 0.0;
    vec2 jitter = (vec2(noise(vUv * 90.0 + boil * 17.0), noise(vUv * 90.0 + 43.0 + boil * 9.0)) - 0.5) * wobble;
    vec2 uv = vUv + jitter;
    vec2 px = lineWidth / resolution;

    float rawDepth = texture2D(tDepth, vUv).x;
    bool isSky = rawDepth >= 0.99999;
    vec3 src = texture2D(tColor, vUv).rgb;

    // ---- Sobel on linear depth (relative) and normals -> ink lines
    float dC = viewDist(uv);
    float dL = viewDist(uv - vec2(px.x, 0.0)), dR = viewDist(uv + vec2(px.x, 0.0));
    float dU = viewDist(uv + vec2(0.0, px.y)), dD = viewDist(uv - vec2(0.0, px.y));
    float depthEdge = (abs(dL - dR) + abs(dU - dD)) / max(dC, 0.001);
    vec3 nC = nrm(uv);
    float normalEdge = (1.0 - dot(nC, nrm(uv - vec2(px.x, 0.0)))) + (1.0 - dot(nC, nrm(uv + vec2(px.x, 0.0))))
                     + (1.0 - dot(nC, nrm(uv + vec2(0.0, px.y)))) + (1.0 - dot(nC, nrm(uv - vec2(0.0, px.y))));
    float edge = depthEdge * edgeDepth * 6.0 + normalEdge * edgeNormal;
    // brush pressure: lines break up slightly, like a dry brush
    float pressure = smoothstep(0.15, 0.65, fbm(uv * vec2(260.0, 260.0) + boil));
    edge = smoothstep(edgeThreshold, edgeThreshold * 2.2, edge) * mix(0.55, 1.0, pressure);
    float distFade = 1.0 - smoothstep(lineFadeFar * 0.35, lineFadeFar, dC);
    edge *= distFade;

    // ---- Ink-wash tone: luminance -> soft posterized value bands
    float lum = dot(src, vec3(0.299, 0.587, 0.114));
    lum = clamp((lum - 0.5) * contrast + 0.5, 0.0, 1.0);
    float banded = floor(lum * toneSteps) / max(toneSteps - 1.0, 1.0);
    float tone = clamp(mix(banded, lum, toneSoftness), 0.0, 1.0);
    // wash bleed: low-frequency paper-noise modulates tone like pooled ink
    tone = clamp(tone + (fbm(uv * 6.0) - 0.5) * 0.12, 0.0, 1.0);
    vec3 col = mix(ink, paper, tone);

    // ---- Vermilion survives: saturated reds keep their hue
    float mx = max(src.r, max(src.g, src.b)), mn = min(src.r, min(src.g, src.b));
    float sat = (mx - mn) / max(mx, 0.0001);
    float redness = smoothstep(0.16, 0.32, src.r - max(src.g, src.b));
    float redMask = smoothstep(0.4, 0.65, sat) * redness * vermilionKeep;
    col = mix(col, vermilion * mix(0.55, 1.15, tone), redMask);

    // ---- Aerial perspective: distance dissolves into paper
    float fog = isSky ? 0.0 : smoothstep(fogNear, fogFar, dC);
    col = mix(col, paper, fog * 0.92);

    if (isSky) {
      // sky passes through its own painted colour, gently paper-blended
      col = mix(src, paper, 0.12);
      edge = 0.0;
    }

    // ---- Ink lines over everything
    col = mix(col, ink, clamp(edge, 0.0, 1.0) * 0.92);

    // ---- Paper: fibres + grain + vignette
    float fib = fbm(vec2(vUv.x * 900.0, vUv.y * 140.0)) * 0.6 + fbm(vUv * resolution * 0.35) * 0.4;
    col *= 1.0 - grain * (fib - 0.35);
    vec2 vc = vUv - 0.5;
    col *= 1.0 - vignette * smoothstep(0.25, 0.85, dot(vc, vc) * 2.2);

    gl_FragColor = vec4(col, 1.0);
    #include <colorspace_fragment>
  }
`;

export class InkRenderer {
  constructor(canvas) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.info.autoReset = false; // we render 3 passes; reset once per frame in render()

    const size = this.renderer.getDrawingBufferSize(new THREE.Vector2());
    this.colorRT = new THREE.WebGLRenderTarget(size.x, size.y, {
      type: THREE.HalfFloatType,
      depthTexture: new THREE.DepthTexture(size.x, size.y),
    });
    this.normalRT = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType });
    this.normalMat = new THREE.MeshNormalMaterial();

    this.uniforms = {
      tColor: { value: this.colorRT.texture },
      tDepth: { value: this.colorRT.depthTexture },
      tNormal: { value: this.normalRT.texture },
      resolution: { value: size.clone() },
      cameraNear: { value: 0.1 },
      cameraFar: { value: 1000 },
      time: { value: 0 },
      paper: { value: new THREE.Color() },
      ink: { value: new THREE.Color() },
      vermilion: { value: new THREE.Color() },
    };
    for (const k of ['toneSteps', 'toneSoftness', 'contrast', 'edgeDepth', 'edgeNormal', 'edgeThreshold', 'lineWidth',
      'lineFadeFar', 'wobble', 'boilFps', 'grain', 'fogNear', 'fogFar', 'vermilionKeep', 'vignette']) {
      this.uniforms[k] = { value: 0 };
    }
    this.syncParams();

    this.post = new THREE.Mesh(
      new THREE.PlaneGeometry(2, 2),
      new THREE.ShaderMaterial({ uniforms: this.uniforms, vertexShader: FULLSCREEN_VERT, fragmentShader: INK_FRAG, depthTest: false, depthWrite: false })
    );
    this.postScene = new THREE.Scene();
    this.postScene.add(this.post);
    this.postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  }

  /** Re-read INK (call after editing config live). */
  syncParams() {
    this.uniforms.paper.value.set(INK.paper);
    this.uniforms.ink.value.set(INK.ink);
    this.uniforms.vermilion.value.set(INK.vermilion);
    for (const k of Object.keys(INK)) {
      if (this.uniforms[k] && typeof INK[k] === 'number') this.uniforms[k].value = INK[k];
    }
  }

  setSize(w, h) {
    this.renderer.setSize(w, h, false);
    const s = this.renderer.getDrawingBufferSize(new THREE.Vector2());
    this.colorRT.setSize(s.x, s.y);
    this.normalRT.setSize(s.x, s.y);
    this.uniforms.resolution.value.copy(s);
  }

  render(scene, camera, time) {
    const r = this.renderer;
    r.info.reset();
    this.uniforms.cameraNear.value = camera.near;
    this.uniforms.cameraFar.value = camera.far;
    this.uniforms.time.value = time;

    // 1) colour + depth (solid + atmosphere)
    camera.layers.enable(LAYER_SOLID);
    camera.layers.enable(LAYER_ATMOS);
    r.setRenderTarget(this.colorRT);
    r.render(scene, camera);

    // 2) view-space normals (solid only, no shadows needed)
    const prevOverride = scene.overrideMaterial;
    const prevBg = scene.background;
    const prevShadow = r.shadowMap.autoUpdate;
    r.shadowMap.autoUpdate = false;
    scene.overrideMaterial = this.normalMat;
    scene.background = null;
    camera.layers.set(LAYER_SOLID);
    r.setRenderTarget(this.normalRT);
    r.setClearColor(0x8080ff, 1);
    r.clear();
    r.render(scene, camera);
    scene.overrideMaterial = prevOverride;
    scene.background = prevBg;
    r.shadowMap.autoUpdate = prevShadow;
    camera.layers.enable(LAYER_ATMOS);

    // 3) ink composite to screen
    r.setRenderTarget(null);
    r.render(this.postScene, this.postCam);
  }
}

import * as THREE from 'three';

// A 3-band toon ramp. The ink pass posterizes again, so this only needs to
// separate lit / half / shadow cleanly. NearestFilter keeps the bands crisp.
let ramp;
function toonRamp() {
  if (ramp) return ramp;
  const data = new Uint8Array([118, 118, 118, 255, 196, 196, 196, 255, 255, 255, 255, 255]);
  ramp = new THREE.DataTexture(data, 3, 1, THREE.RGBAFormat);
  ramp.minFilter = ramp.magFilter = THREE.NearestFilter;
  ramp.generateMipmaps = false;
  ramp.needsUpdate = true;
  return ramp;
}

const cache = new Map();
/** Shared toon material per colour. Colours are VALUES first: think in greys. */
export function toon(color, opts = {}) {
  const key = `${color}|${opts.side ?? 0}|${opts.flat ? 1 : 0}`;
  if (!opts.map && cache.has(key)) return cache.get(key);
  const m = new THREE.MeshToonMaterial({
    color: new THREE.Color(color),
    gradientMap: toonRamp(),
    side: opts.side ?? THREE.FrontSide,
    map: opts.map ?? null,
  });
  m.flatShading = !!opts.flat;
  if (!opts.map) cache.set(key, m);
  return m;
}

/** Convert any loaded GLB material (PBR) to toon, keeping its base colour map. */
export function toonify(root) {
  root.traverse((o) => {
    if (!o.isMesh) return;
    const src = Array.isArray(o.material) ? o.material : [o.material];
    const out = src.map((m) => {
      const t = new THREE.MeshToonMaterial({
        color: m.color ? m.color.clone() : new THREE.Color('#999'),
        map: m.map ?? null,
        gradientMap: toonRamp(),
        transparent: m.transparent,
        alphaTest: m.alphaTest,
        side: m.side,
      });
      return t;
    });
    o.material = Array.isArray(o.material) ? out : out[0];
    o.castShadow = true;
    o.receiveShadow = true;
  });
}

export const PALETTE = {
  stoneLight: '#d8d2c6',
  stone: '#b3ada2',
  stoneDark: '#868076',
  pine: '#2b2a27',
  bark: '#3c352d',
  straw: '#cdb995',
  robe: '#4a5060',
  cloth: '#e3dac6',
  vermilion: '#b8392a',
  lantern: '#9a948a',
};

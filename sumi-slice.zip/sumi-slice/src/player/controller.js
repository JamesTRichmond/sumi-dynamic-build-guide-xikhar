import * as THREE from 'three';
import { PLAYER } from '../config.js';

const UP = new THREE.Vector3(0, 1, 0);
const _ray = new THREE.Raycaster();
const _v = new THREE.Vector3();
const _n = new THREE.Vector3();
const _origin = new THREE.Vector3();

/**
 * Kinematic character controller. No physics engine: raycasts against
 * level colliders for ground (with step-up + slope limit) and walls (slide).
 * Feel lives in PLAYER config: coyote time, jump buffer, accel curves.
 */
export class Controller {
  constructor() {
    this.position = new THREE.Vector3();
    this.velocity = new THREE.Vector3();
    this.facing = 0;                 // yaw the body looks toward
    this.grounded = false;
    this.groundNormal = new THREE.Vector3(0, 1, 0);
    this.sinceGrounded = 99;
    this.sinceJumpPress = 99;
    this.colliders = [];
    this.events = { jumped: false, landed: false };
    this.checkpoint = new THREE.Vector3();
    this.checkpointYaw = 0;
  }

  setColliders(list) { this.colliders = list; }

  teleport(pos, yaw = this.facing) {
    this.position.copy(pos);
    this.velocity.set(0, 0, 0);
    this.facing = yaw;
    this.snapToGround(3);
  }

  snapToGround(maxDrop) {
    const hit = this.groundRay(maxDrop);
    if (hit) this.position.y = hit.point.y;
  }

  groundRay(below) {
    _origin.copy(this.position).addScaledVector(UP, PLAYER.stepHeight + 0.05);
    _ray.set(_origin, _v.set(0, -1, 0));
    _ray.far = PLAYER.stepHeight + 0.05 + below;
    const hits = _ray.intersectObjects(this.colliders, false);
    for (const h of hits) {
      if (!h.face) continue;
      _n.copy(h.face.normal).transformDirection(h.object.matrixWorld);
      h.worldNormal = _n.clone();
      return h;
    }
    return null;
  }

  /** Cancel horizontal motion into walls at knee and chest height. */
  collideWalls(delta) {
    const len = Math.hypot(delta.x, delta.z);
    if (len < 1e-5) return;
    const dir = _v.set(delta.x / len, 0, delta.z / len);
    for (const h of [PLAYER.stepHeight + 0.1, PLAYER.height * 0.75]) {
      _origin.copy(this.position).setY(this.position.y + h);
      _ray.set(_origin, dir);
      _ray.far = len + PLAYER.radius;
      const hit = _ray.intersectObjects(this.colliders, false)[0];
      if (!hit || !hit.face) continue;
      _n.copy(hit.face.normal).transformDirection(hit.object.matrixWorld);
      _n.y = 0;
      if (_n.lengthSq() < 1e-4) continue;
      _n.normalize();
      // remove the component of motion pointing into the wall, keep the slide
      const into = delta.x * _n.x + delta.z * _n.z;
      if (into < 0) { delta.x -= _n.x * into; delta.z -= _n.z * into; }
      const pen = PLAYER.radius - (hit.distance - len);
      if (pen > 0 && hit.distance < PLAYER.radius) { delta.x += _n.x * (PLAYER.radius - hit.distance); delta.z += _n.z * (PLAYER.radius - hit.distance); }
    }
  }

  /**
   * @param dt seconds
   * @param intent from Input.read()
   * @param camYaw camera yaw so input is camera-relative
   */
  update(dt, intent, camYaw) {
    this.events.jumped = this.events.landed = false;
    // camera-relative wish direction
    const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw);
    const rx = Math.cos(camYaw), rz = -Math.sin(camYaw);
    const wishX = fx * intent.move.y + rx * intent.move.x;
    const wishZ = fz * intent.move.y + rz * intent.move.x;
    const wishLen = Math.min(1, Math.hypot(wishX, wishZ));
    const speed = (intent.run ? PLAYER.runSpeed : PLAYER.walkSpeed) * wishLen;

    // horizontal acceleration (separate accel/decel = snappy starts, weighty stops)
    const control = this.grounded ? 1 : PLAYER.airControl;
    const tx = wishLen > 0 ? (wishX / wishLen) * speed : 0;
    const tz = wishLen > 0 ? (wishZ / wishLen) * speed : 0;
    const rate = (wishLen > 0 ? PLAYER.accel : PLAYER.decel) * control * dt;
    const dvx = tx - this.velocity.x, dvz = tz - this.velocity.z;
    const dl = Math.hypot(dvx, dvz);
    if (dl <= rate) { this.velocity.x = tx; this.velocity.z = tz; }
    else { this.velocity.x += (dvx / dl) * rate; this.velocity.z += (dvz / dl) * rate; }

    // jump with coyote time + input buffer
    this.sinceJumpPress = intent.jump ? 0 : this.sinceJumpPress + dt;
    this.sinceGrounded = this.grounded ? 0 : this.sinceGrounded + dt;
    if (this.sinceJumpPress <= PLAYER.jumpBuffer && this.sinceGrounded <= PLAYER.coyoteTime && this.velocity.y <= 0.01) {
      this.velocity.y = PLAYER.jumpVelocity;
      this.grounded = false;
      this.sinceGrounded = 99;
      this.sinceJumpPress = 99;
      this.events.jumped = true;
    }

    // gravity (a little heavier on the way down: snappier arcs)
    const g = PLAYER.gravity * (this.velocity.y < 0 ? 1.35 : 1);
    this.velocity.y += g * dt;

    // move horizontally with wall slide
    const delta = new THREE.Vector3(this.velocity.x * dt, 0, this.velocity.z * dt);
    this.collideWalls(delta);
    this.position.x += delta.x;
    this.position.z += delta.z;

    // vertical + ground snap (step-up comes free: ray starts stepHeight above feet)
    this.position.y += this.velocity.y * dt;
    const wasGrounded = this.grounded;
    const hit = this.velocity.y <= 0 ? this.groundRay(wasGrounded ? 0.35 : 0.05) : null;
    const maxSlopeCos = Math.cos(THREE.MathUtils.degToRad(PLAYER.maxSlopeDeg));
    if (hit && hit.worldNormal.y >= maxSlopeCos && hit.point.y >= this.position.y - 0.36) {
      this.position.y = hit.point.y;
      this.velocity.y = 0;
      this.grounded = true;
      this.groundNormal.copy(hit.worldNormal);
      if (!wasGrounded) this.events.landed = true;
    } else {
      this.grounded = false;
    }

    // face movement direction
    if (wishLen > 0.1) {
      const target = Math.atan2(this.velocity.x, this.velocity.z);
      let d = target - this.facing;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      this.facing += d * Math.min(1, PLAYER.turnRate * dt);
    }

    // checkpoints + fall reset
    if (this.grounded && wishLen === 0) { this.checkpoint.copy(this.position); this.checkpointYaw = this.facing; }
    if (this.position.y < PLAYER.killY) this.teleport(this.checkpoint, this.checkpointYaw);
  }

  get horizontalSpeed() { return Math.hypot(this.velocity.x, this.velocity.z); }
}

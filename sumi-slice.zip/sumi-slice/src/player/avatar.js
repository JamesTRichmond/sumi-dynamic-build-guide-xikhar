import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { toon, toonify, PALETTE } from '../ink/materials.js';
import { Ribbon } from './cloth.js';
import { PLAYER } from '../config.js';

/**
 * Avatar contract (both the placeholder and the GLB hero implement it):
 *   root: Object3D at the feet, facing +Z
 *   ribbons: Ribbon[] (add their .mesh to the scene, not to root)
 *   update(dt, controller, time)
 */
export async function createAvatar() {
  // public/models/manifest.json -> { "hero": "ronin.glb" } once the GLB exists.
  // (A manifest avoids probing for a missing file, which logs a 404 and fails QA.)
  let hero = '';
  try { hero = (await (await fetch('./models/manifest.json')).json()).hero ?? ''; } catch { hero = ''; }
  const glb = hero ? await tryLoadHero(`./models/${hero}`) : null;
  return glb ?? createPlaceholder();
}

// ------------------------------------------------------------ placeholder
function createPlaceholder() {
  const root = new THREE.Group();
  root.name = 'avatar-placeholder';
  const body = new THREE.Group();
  root.add(body);
  const robe = toon(PALETTE.robe), skin = toon('#cbb9a0'), straw = toon(PALETTE.straw, { flat: true });
  const dark = toon('#1e1c1a'), red = toon(PALETTE.vermilion), cloth = toon(PALETTE.cloth);

  const profile = [[0.0, 0.62], [0.3, 0.64], [0.26, 0.8], [0.2, 0.96], [0.23, 1.2], [0.25, 1.36], [0.1, 1.46], [0.0, 1.47]].map(([r, y]) => new THREE.Vector2(r, y));
  const torso = new THREE.Mesh(new THREE.LatheGeometry(profile, 14), robe);
  body.add(torso);
  const sash = new THREE.Mesh(new THREE.TorusGeometry(0.205, 0.045, 6, 18), red);
  sash.rotation.x = Math.PI / 2; sash.position.y = 0.97;
  body.add(sash);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.115, 14, 10), skin);
  head.position.y = 1.58;
  body.add(head);
  const hat = new THREE.Mesh(new THREE.ConeGeometry(0.44, 0.22, 20, 1, true), straw);
  hat.position.y = 1.75;
  body.add(hat);
  const hatCap = new THREE.Mesh(new THREE.CircleGeometry(0.44, 20), straw);
  hatCap.rotation.x = Math.PI / 2; hatCap.position.y = 1.64;
  body.add(hatCap);

  const legs = [];
  for (const sx of [-1, 1]) {
    const hip = new THREE.Group();
    hip.position.set(sx * 0.11, 0.66, 0);
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 0.62, 8), robe);
    leg.position.y = -0.31;
    const wrap = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.07, 0.18, 8), cloth);
    wrap.position.y = -0.5;
    hip.add(leg, wrap);
    body.add(hip);
    legs.push(hip);
  }
  const arms = [];
  for (const sx of [-1, 1]) {
    const sh = new THREE.Group();
    sh.position.set(sx * 0.27, 1.32, 0);
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.1, 0.55, 8), robe);
    arm.position.y = -0.27;
    sh.add(arm);
    body.add(sh);
    arms.push(sh);
  }
  const sword = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, 1.0), dark);
  sword.position.set(0.24, 0.95, -0.05); sword.rotation.set(0.5, 0, 0.15);
  body.add(sword);
  const gourd = new THREE.Group();
  const g1 = new THREE.Mesh(new THREE.SphereGeometry(0.075, 10, 8), straw); g1.position.y = -0.05;
  const g2 = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), straw); g2.position.y = 0.06;
  gourd.add(g1, g2); gourd.position.set(-0.25, 0.86, -0.1);
  body.add(gourd);
  root.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });

  const neck = new THREE.Object3D(); neck.position.set(-0.1, 1.42, -0.15); body.add(neck);
  const waist = new THREE.Object3D(); waist.position.set(0.08, 0.98, -0.2); body.add(waist);
  const colliders = [{ object: body, offset: new THREE.Vector3(0, 1.1, 0), radius: 0.3 }, { object: body, offset: new THREE.Vector3(0, 0.6, 0), radius: 0.34 }];
  const ribbons = [
    new Ribbon({ anchor: neck, segments: 12, length: 0.95, width: 0.075, color: '#d6cdb9', colliders, wind: 1.4 }),
    new Ribbon({ anchor: waist, segments: 8, length: 0.55, width: 0.09, color: PALETTE.vermilion, colliders, wind: 0.7 }),
  ];

  let phase = 0, lean = 0, prevSpeed = 0;
  return {
    root, ribbons, kind: 'placeholder',
    update(dt, ctl, time) {
      const speed = ctl.horizontalSpeed;
      const k = Math.min(1, speed / PLAYER.runSpeed);
      phase += dt * (4 + speed * 1.6);
      const swing = ctl.grounded ? Math.sin(phase) * (0.25 + k * 0.55) * Math.min(1, speed) : 0.5;
      legs[0].rotation.x = ctl.grounded ? swing : -0.6;
      legs[1].rotation.x = ctl.grounded ? -swing : 0.3;
      arms[0].rotation.x = -swing * 0.7;
      arms[1].rotation.x = swing * 0.7;
      body.position.y = ctl.grounded ? Math.abs(Math.sin(phase)) * 0.045 * Math.min(1, speed) : 0;
      const accel = (speed - prevSpeed) / Math.max(dt, 1e-3);
      prevSpeed = speed;
      lean = THREE.MathUtils.damp(lean, THREE.MathUtils.clamp(k * 0.18 + accel * 0.006, -0.1, 0.3), 8, dt);
      body.rotation.x = lean;
      root.position.copy(ctl.position);
      root.rotation.y = ctl.facing;
      for (const r of ribbons) r.update(dt, time);
    },
  };
}

// ------------------------------------------------------------ GLB hero
async function tryLoadHero(url) {
  let buf;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    buf = await res.arrayBuffer();
    if (buf.byteLength < 12 || new TextDecoder().decode(new Uint8Array(buf, 0, 4)) !== 'glTF') return null;
  } catch { return null; }

  const loader = new GLTFLoader();
  loader.setMeshoptDecoder(MeshoptDecoder);
  const gltf = await loader.parseAsync(buf, './models/');
  const model = gltf.scene;
  toonify(model);

  // normalise: feet at 0, height = PLAYER.height, facing +Z
  const box = new THREE.Box3().setFromObject(model);
  const h = box.max.y - box.min.y;
  model.scale.setScalar(PLAYER.height / h);
  box.setFromObject(model);
  model.position.y -= box.min.y;
  const root = new THREE.Group();
  root.name = 'avatar-hero';
  const facingFix = new THREE.Group();
  facingFix.rotation.y = HERO.yawOffset;
  facingFix.add(model);
  root.add(facingFix);

  // animation: match clip names loosely so Tripo / Blender exports both work
  const mixer = new THREE.AnimationMixer(model);
  const find = (re) => gltf.animations.find((c) => re.test(c.name));
  const clips = { idle: find(/idle|stand|breath/i), walk: find(/walk/i), run: find(/run|jog|sprint/i), jump: find(/jump|fall|air/i) };
  const actions = {};
  for (const [k, c] of Object.entries(clips)) if (c) { actions[k] = mixer.clipAction(c); actions[k].play(); actions[k].setEffectiveWeight(0); }
  if (actions.idle) actions.idle.setEffectiveWeight(1);

  // cloth anchors on real bones
  let neck = null, hips = null;
  model.traverse((o) => {
    if (!o.isBone) return;
    if (!neck && /neck|upperchest|spine2/i.test(o.name)) neck = o;
    if (!hips && /hips|pelvis/i.test(o.name)) hips = o;
  });
  const anchorOn = (bone, offset) => { const a = new THREE.Object3D(); a.position.copy(offset); (bone ?? model).add(a); return a; };
  const colliders = [{ object: root, offset: new THREE.Vector3(0, 1.1, 0), radius: 0.3 }, { object: root, offset: new THREE.Vector3(0, 0.6, 0), radius: 0.34 }];
  const ribbons = HERO.ribbons ? [
    new Ribbon({ anchor: anchorOn(neck, new THREE.Vector3(0, 0, -0.1 / model.scale.x)), segments: 12, length: 0.95, width: 0.11, color: PALETTE.cloth, colliders }),
  ] : [];

  const w = { idle: 1, walk: 0, run: 0, jump: 0 };
  let bob = 0;
  return {
    root, ribbons, kind: 'hero', clips: Object.fromEntries(Object.entries(clips).map(([k, c]) => [k, c?.name ?? null])),
    update(dt, ctl, time) {
      const s = ctl.horizontalSpeed;
      const target = { idle: 0, walk: 0, run: 0, jump: 0 };
      if (!ctl.grounded && actions.jump) target.jump = 1;
      else if (s < 0.2) target.idle = 1;
      else if (s < (PLAYER.walkSpeed + PLAYER.runSpeed) / 2 || !actions.run) target.walk = 1;
      else target.run = 1;
      for (const k of Object.keys(w)) {
        w[k] = THREE.MathUtils.damp(w[k], target[k], 10, dt);
        actions[k]?.setEffectiveWeight(w[k]);
      }
      if (actions.walk) actions.walk.timeScale = Math.max(0.6, s / PLAYER.walkSpeed);
      if (actions.run) actions.run.timeScale = Math.max(0.7, s / PLAYER.runSpeed);
      mixer.update(dt);
      if (!gltf.animations.length) { bob += dt * (4 + s * 1.6); model.position.y = Math.abs(Math.sin(bob)) * 0.03 * Math.min(1, s); }
      root.position.copy(ctl.position);
      root.rotation.y = ctl.facing;
      for (const r of ribbons) r.update(dt, time);
    },
  };
}

/** Per-hero fixes an agent may need after import. */
export const HERO = {
  yawOffset: 0,   // set to Math.PI if the GLB faces -Z
  ribbons: true,  // procedural scarf on the neck bone
};

import * as THREE from 'three';
import { toon } from '../ink/materials.js';

const _a = new THREE.Vector3();
const _b = new THREE.Vector3();
const _side = new THREE.Vector3();

/**
 * Verlet ribbon: scarf tails, sash ends, hat cords, banners.
 * Pinned to an Object3D (a bone or an empty). Inherits motion from the anchor,
 * so running, turning and jumping all make it trail naturally.
 * Collides with a list of spheres (body approximation) so it never clips into the torso.
 */
export class Ribbon {
  constructor({ anchor, segments = 10, length = 1.1, width = 0.16, color = '#e3dac6', gravity = -9.8, damping = 0.985, wind = 1.0, colliders = [] }) {
    this.anchor = anchor;
    this.n = segments + 1;
    this.rest = length / segments;
    this.width = width;
    this.gravity = gravity;
    this.damping = damping;
    this.wind = wind;
    this.colliders = colliders; // [{ object, offset: Vector3, radius }]
    this.pos = Array.from({ length: this.n }, () => new THREE.Vector3());
    this.prev = Array.from({ length: this.n }, () => new THREE.Vector3());
    this.reset();

    const geo = new THREE.BufferGeometry();
    const verts = new Float32Array(this.n * 2 * 3);
    const uvs = new Float32Array(this.n * 2 * 2);
    const idx = [];
    for (let i = 0; i < this.n; i++) {
      uvs.set([0, i / (this.n - 1), 1, i / (this.n - 1)], i * 4);
      if (i < this.n - 1) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    }
    geo.setAttribute('position', new THREE.BufferAttribute(verts, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(idx);
    this.mesh = new THREE.Mesh(geo, toon(color, { side: THREE.DoubleSide }));
    this.mesh.castShadow = true;
    this.mesh.frustumCulled = false;
  }

  reset() {
    this.anchor.updateWorldMatrix(true, false);
    this.anchor.getWorldPosition(_a);
    for (let i = 0; i < this.n; i++) { this.pos[i].set(_a.x, _a.y - i * this.rest, _a.z); this.prev[i].copy(this.pos[i]); }
  }

  update(dt, time) {
    dt = Math.min(dt, 1 / 30);
    this.anchor.updateWorldMatrix(true, false);
    this.anchor.getWorldPosition(_b);
    if (_b.distanceTo(this.pos[0]) > 2) { this.reset(); return; } // teleported: don't fling
    this.pos[0].copy(_b);
    this.prev[0].copy(this.pos[0]);
    const gust = (Math.sin(time * 1.3) * 0.5 + Math.sin(time * 3.7 + 1.2) * 0.3 + 0.6) * this.wind;
    for (let i = 1; i < this.n; i++) {
      const p = this.pos[i], q = this.prev[i];
      _a.subVectors(p, q).multiplyScalar(this.damping);
      q.copy(p);
      p.add(_a);
      p.y += this.gravity * dt * dt;
      p.x += gust * 1.4 * dt * dt * (0.6 + i / this.n);
      p.z += Math.sin(time * 2.1 + i * 0.6) * gust * 0.8 * dt * dt;
    }
    for (let k = 0; k < 6; k++) {
      for (let i = 0; i < this.n - 1; i++) {
        const a = this.pos[i], b = this.pos[i + 1];
        _a.subVectors(b, a);
        const d = _a.length() || 1e-6;
        const diff = (d - this.rest) / d;
        if (i === 0) b.addScaledVector(_a, -diff);
        else { a.addScaledVector(_a, diff * 0.5); b.addScaledVector(_a, -diff * 0.5); }
      }
      for (const c of this.colliders) {
        c.object.localToWorld(_b.copy(c.offset));
        for (let i = 1; i < this.n; i++) {
          _a.subVectors(this.pos[i], _b);
          const d = _a.length();
          if (d < c.radius) this.pos[i].copy(_b).addScaledVector(_a, c.radius / (d || 1e-6));
        }
      }
    }
    // rebuild ribbon: width runs along the anchor's local X axis
    _side.set(1, 0, 0).transformDirection(this.anchor.matrixWorld).multiplyScalar(this.width / 2);
    const arr = this.mesh.geometry.attributes.position.array;
    for (let i = 0; i < this.n; i++) {
      const taper = 1 - (i / (this.n - 1)) * 0.35;
      const p = this.pos[i];
      arr[i * 6 + 0] = p.x - _side.x * taper; arr[i * 6 + 1] = p.y - _side.y * taper; arr[i * 6 + 2] = p.z - _side.z * taper;
      arr[i * 6 + 3] = p.x + _side.x * taper; arr[i * 6 + 4] = p.y + _side.y * taper; arr[i * 6 + 5] = p.z + _side.z * taper;
    }
    this.mesh.geometry.attributes.position.needsUpdate = true;
    this.mesh.geometry.computeVertexNormals();
  }
}

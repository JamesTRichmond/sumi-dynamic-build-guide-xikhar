import * as THREE from 'three';
import { InkRenderer } from './ink/InkRenderer.js';
import { makeSky } from './world/atmosphere.js';
import { LevelManager } from './world/LevelManager.js';
import { Controller } from './player/controller.js';
import { createAvatar } from './player/avatar.js';
import { FollowCam } from './camera/followCam.js';
import { Input } from './core/input.js';
import { INK, WORLD, PLAYER } from './config.js';

const canvas = document.createElement('canvas');
canvas.tabIndex = 0;
document.body.prepend(canvas);

const ink = new InkRenderer(canvas);
const scene = new THREE.Scene();
scene.background = new THREE.Color(INK.paper);

// ---- light: one warm key from upper-left, cool sky fill. Shadows only from the key.
const hemi = new THREE.HemisphereLight('#f4ecdc', '#8a847a', 1.6);
const sun = new THREE.DirectionalLight('#fff6e6', 2.4);
sun.position.set(...WORLD.sunDir).multiplyScalar(40);
sun.castShadow = true;
sun.shadow.mapSize.set(WORLD.shadowMapSize, WORLD.shadowMapSize);
Object.assign(sun.shadow.camera, { left: -22, right: 22, top: 22, bottom: -22, near: 1, far: 120 });
sun.shadow.bias = -0.0006;
sun.shadow.normalBias = 0.03;
scene.add(hemi, sun, sun.target, makeSky());

const levels = new LevelManager(scene);
const player = new Controller();
const cam = new FollowCam(innerWidth / innerHeight);
const input = new Input(canvas);
let avatar;

function enterLevel(level) {
  player.setColliders(level.colliders);
  cam.colliders = level.colliders;
  player.teleport(level.spawn, level.spawnYaw);
  player.checkpoint.copy(player.position);
  player.checkpointYaw = level.spawnYaw;
  cam.snapBehind(player.position, player.facing);
  avatar?.ribbons.forEach((r) => r.reset());
}

function resize() {
  ink.setSize(innerWidth, innerHeight);
  cam.camera.aspect = innerWidth / innerHeight;
  cam.camera.updateProjectionMatrix();
}
addEventListener('resize', resize);

// ---- level exit: ink wipe, then next level
const wipe = document.getElementById('wipe');
const wipeText = document.getElementById('wipe-text');
let transitioning = false;
async function completeLevel() {
  transitioning = true;
  wipeText.textContent = levels.level.title;
  wipe.classList.add('on');
  await new Promise((r) => setTimeout(r, 1400));
  enterLevel(levels.next());
  wipeText.textContent = levels.level.title;
  await new Promise((r) => setTimeout(r, 500));
  wipe.classList.remove('on');
  transitioning = false;
}

// ---- debug: F1 stats, F2 live ink panel (lil-gui is a dev dependency)
const statsEl = document.getElementById('stats');
let gui = null;
addEventListener('keydown', async (e) => {
  if (e.code === 'F1') { e.preventDefault(); statsEl.style.display = statsEl.style.display === 'block' ? 'none' : 'block'; }
  if (e.code === 'F2') {
    e.preventDefault();
    if (gui) { gui.destroy(); gui = null; return; }
    const { default: GUI } = await import('lil-gui');
    gui = new GUI({ title: 'Ink — copy values into src/config.js' });
    for (const k of Object.keys(INK)) {
      if (typeof INK[k] === 'string') gui.addColor(INK, k).onChange(() => ink.syncParams());
      else gui.add(INK, k, 0, k.startsWith('fog') || k === 'lineFadeFar' ? 400 : k === 'toneSteps' ? 8 : k === 'boilFps' ? 24 : 3, 0.001).onChange(() => ink.syncParams());
    }
    gui.add({ dump: () => console.log(JSON.stringify(INK, null, 2)) }, 'dump').name('log values to console');
  }
});

// ---- QA hooks: scripts/qa.mjs drives these. Keep them stable.
const fpsSamples = [];
window.__qa = {
  ready: false,
  errors: [],
  fps: () => (fpsSamples.length ? fpsSamples.reduce((a, b) => a + b, 0) / fpsSamples.length : 0),
  info: () => ({ calls: ink.renderer.info.render.calls, triangles: ink.renderer.info.render.triangles, geometries: ink.renderer.info.memory.geometries, textures: ink.renderer.info.memory.textures, avatar: avatar?.kind, clips: avatar?.clips ?? null, level: levels.level?.id }),
  shots: () => Object.keys(levels.level?.shots ?? {}),
  shot(name) {
    const s = levels.level.shots[name];
    if (!s) throw new Error(`no shot "${name}" in level ${levels.level.id}`);
    player.teleport(new THREE.Vector3(...s.pos).add(new THREE.Vector3(0, 1.5, 0)), s.yaw);
    cam.snapBehind(player.position, s.yaw);
    cam.pitch = s.pitch;
    cam.place(1);
    avatar.ribbons.forEach((r) => r.reset());
    return true;
  },
  state: () => ({ pos: player.position.toArray(), grounded: player.grounded, speed: player.horizontalSpeed }),
  /** Live scripted input (used while a person watches with --headed). */
  drive: null,
  /**
   * Deterministic simulation for tests: runs `seconds` of game time at a fixed 60 Hz
   * with intent {x, y, run, jump}, independent of render speed. Returns the trace.
   */
  simulate(seconds, { x = 0, y = 0, run = false, jump = false } = {}) {
    const dt = 1 / 60;
    const trace = { leftGround: false, landed: false, jumped: false };
    for (let i = 0; i < Math.round(seconds * 60); i++) {
      const intent = { move: { x, y }, run, jump: jump && i === 0, lookX: 0, lookY: 0, stickX: 0, stickY: 0, lookActive: false };
      player.update(dt, intent, cam.yaw);
      cam.update(dt, intent, player);
      avatar.update(dt, player, time + i * dt);
      if (!player.grounded) trace.leftGround = true;
      if (player.events.landed) trace.landed = true;
      if (player.events.jumped) trace.jumped = true;
    }
    return { ...trace, ...window.__qa.state() };
  },
};
addEventListener('error', (e) => window.__qa.errors.push(String(e.message)));

// ---- loop
const clock = new THREE.Clock();
let time = 0;
async function boot() {
  avatar = await createAvatar();
  scene.add(avatar.root);
  for (const r of avatar.ribbons) scene.add(r.mesh);
  enterLevel(levels.load(0));
  resize();
  ink.renderer.setAnimationLoop(frame);
}

function frame() {
  const dt = Math.min(clock.getDelta(), 1 / 20);
  time += dt;
  const intent = input.read();
  if (window.__qa.drive) {
    const d = window.__qa.drive;
    intent.move.x = d.x ?? 0; intent.move.y = d.y ?? 0; intent.run = !!d.run; intent.jump = !!d.jump; d.jump = false;
  }
  if (!transitioning) player.update(dt, intent, cam.yaw);
  cam.update(dt, intent, player);
  avatar.update(dt, player, time);
  levels.level.update?.(time);
  scene.children.forEach((c) => c.material?.uniforms?.time && (c.material.uniforms.time.value = time));

  // shadow camera follows the player so 2048px covers what matters
  sun.target.position.copy(player.position);
  sun.position.copy(player.position).add(new THREE.Vector3(...WORLD.sunDir).multiplyScalar(40));

  if (!transitioning && levels.level.exit?.containsPoint(player.position.clone().setY(player.position.y + 1))) completeLevel();

  ink.render(scene, cam.camera, time);

  fpsSamples.push(1 / Math.max(dt, 1e-4));
  if (fpsSamples.length > 120) fpsSamples.shift();
  if (statsEl.style.display === 'block') {
    const i = window.__qa.info();
    statsEl.textContent = `fps ${window.__qa.fps().toFixed(0)}\ncalls ${i.calls}\ntris ${(i.triangles / 1000).toFixed(1)}k\navatar ${i.avatar}\nlevel ${i.level}\npos ${player.position.toArray().map((v) => v.toFixed(1)).join(', ')}\n${player.grounded ? 'grounded' : 'air'}`;
  }
  window.__qa.ready = true;
}

boot().catch((e) => { window.__qa.errors.push(String(e?.stack ?? e)); console.error(e); });
export { PLAYER };

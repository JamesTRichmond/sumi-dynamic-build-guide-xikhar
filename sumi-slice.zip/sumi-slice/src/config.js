// Every tunable in one place. Agents edit THIS file to match the style bible,
// not magic numbers scattered through the code. F2 in-game edits INK live.

export const INK = {
  paper: '#e8dfcb',        // the "white" of the world: aged rice paper
  ink: '#16130f',          // the darkest value; never pure black
  vermilion: '#c2412d',    // the only saturated hue allowed (torii, sash, sun)
  toneSteps: 4,            // ink-wash value bands (3-5 reads as sumi-e)
  toneSoftness: 0.35,      // 0 = hard posterize, 1 = smooth gradient
  contrast: 1.05,          // pre-posterize contrast
  edgeDepth: 0.9,          // depth-discontinuity line strength
  edgeNormal: 1.1,         // crease line strength
  edgeThreshold: 0.12,     // lower = more lines
  lineWidth: 1.5,          // screen-space sample radius in px
  lineFadeFar: 200,        // lines fade out by this distance (aerial perspective)
  wobble: 0.0016,          // hand-drawn line jitter (uv units)
  boilFps: 6,              // how often the jitter re-rolls; 0 = static
  grain: 0.085,            // paper fibre strength
  fogNear: 18,
  fogFar: 240,
  vermilionKeep: 0.9,      // how much saturated red survives the ink conversion
  vignette: 0.32,
};

export const PLAYER = {
  height: 1.7,
  radius: 0.32,
  walkSpeed: 3.4,
  runSpeed: 6.8,
  accel: 30,               // m/s^2 on ground
  decel: 26,
  airControl: 0.35,        // fraction of accel available in the air
  gravity: -26,
  jumpVelocity: 8.6,
  coyoteTime: 0.12,        // seconds you can still jump after leaving a ledge
  jumpBuffer: 0.12,        // seconds a press is remembered before landing
  stepHeight: 0.5,         // max ledge the controller climbs without jumping
  maxSlopeDeg: 48,
  turnRate: 12,            // facing slerp speed
  killY: -30,
};

export const CAM = {
  fov: 50,
  distance: 5.4,
  height: 1.55,            // look-at height above feet
  shoulder: 0.35,          // over-the-shoulder offset
  pitch: 0.2,              // default pitch (radians)
  minPitch: -0.45,
  maxPitch: 1.05,
  sensitivity: 0.0024,
  stickSensitivity: 2.6,
  followLag: 10,           // higher = tighter
  recenterDelay: 1.6,      // seconds without look input before auto-recenter
  recenterSpeed: 1.8,
  collisionPad: 0.3,
};

export const WORLD = {
  sunDir: [-0.55, 0.75, 0.35],
  shadowMapSize: 2048,
  mistLayers: 7,
};

// Keyboard + mouse (pointer lock) + gamepad, merged into one intent object.
export class Input {
  constructor(canvas) {
    this.keys = new Set();
    this.look = { dx: 0, dy: 0 };
    this.jumpPressed = false;
    this.lookActive = false;
    this.locked = false;
    addEventListener('keydown', (e) => {
      if (e.repeat) return;
      this.keys.add(e.code);
      if (e.code === 'Space') { this.jumpPressed = true; e.preventDefault(); }
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());
    canvas.addEventListener('click', () => { if (!this.locked) canvas.requestPointerLock?.(); });
    document.addEventListener('pointerlockchange', () => { this.locked = document.pointerLockElement === canvas; });
    addEventListener('mousemove', (e) => {
      if (!this.locked) return;
      this.look.dx += e.movementX; this.look.dy += e.movementY; this.lookActive = true;
    });
  }

  /** Call once per frame. Returns { move:{x,y}, run, jump, lookX, lookY, stickLook }. */
  read() {
    const k = this.keys;
    let x = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
    let y = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
    let run = k.has('ShiftLeft') || k.has('ShiftRight');
    let jump = this.jumpPressed;
    let sx = 0, sy = 0;
    const pad = navigator.getGamepads?.().find((p) => p && p.connected);
    if (pad) {
      const dz = (v) => (Math.abs(v) < 0.15 ? 0 : v);
      if (dz(pad.axes[0]) || dz(pad.axes[1])) { x = dz(pad.axes[0]); y = -dz(pad.axes[1]); }
      sx = dz(pad.axes[2] ?? 0); sy = dz(pad.axes[3] ?? 0);
      if (pad.buttons[0]?.pressed && !this._padJump) jump = true;
      this._padJump = pad.buttons[0]?.pressed;
      run = run || pad.buttons[10]?.pressed || pad.buttons[7]?.value > 0.5 || Math.hypot(x, y) > 0.92;
    }
    const len = Math.hypot(x, y);
    if (len > 1) { x /= len; y /= len; }
    const out = { move: { x, y }, run, jump, lookX: this.look.dx, lookY: this.look.dy, stickX: sx, stickY: sy, lookActive: this.lookActive || !!(sx || sy) };
    this.look.dx = this.look.dy = 0; this.jumpPressed = false; this.lookActive = false;
    return out;
  }
}
